use super::mem_service::MemService;
use super::redis_pool::{self, RedisPool};
use crate::common::error::Result;
use crate::model::prelude::ListData;
use crate::model::sys::args::acache::CacheItem;
use serde::{Deserialize, Serialize};
#[derive(Clone)]
pub enum CacheService {
    Memory(MemService),
    Redis(RedisPool),
}

impl CacheService {
    // 创建默认的内存缓存
    pub fn new_memory() -> Self {
        CacheService::Memory(MemService::default())
    }

    // 创建 Redis 缓存
    pub async fn new_redis() -> Result<Self> {
        Ok(CacheService::Redis(redis_pool::connect_redis().await))
    }
    pub async fn recycling(&self) {
        match self {
            CacheService::Memory(m) => m.recycling().await,
            CacheService::Redis(_) => {
                println!("Redis cache doesn't need recycling");
            }
        }
    }

    pub async fn set_string(&self, k: &str, v: &str) -> Result<String> {
        match self {
            CacheService::Memory(m) => m.set_string(k, v).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.unwrap();
                redis.set_string(k, v).await
            }
        }
    }
    pub async fn get_string(&self, k: &str) -> Result<String> {
        match self {
            CacheService::Memory(m) => m.get_string(k).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.get_string(k).await
            }
        }
    }

    pub async fn set_string_ex(&self, k: &str, v: &str, t: i32) -> Result<bool> {
        match self {
            CacheService::Memory(m) => m.set_string_ex(k, v, t).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.set_string_ex(k, v, t).await
            }
        }
    }

    pub async fn remove(&self, k: &str) -> Result<usize> {
        match self {
            CacheService::Memory(m) => m.remove(k).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.remove(k).await
            }
        }
    }

    pub async fn contains_key(&self, k: &str) -> bool {
        match self {
            CacheService::Memory(m) => m.contains_key(k).await,
            CacheService::Redis(r) => {
                if let Ok(mut redis) = r.get().await {
                    redis.contains_key(k).await
                } else {
                    false
                }
            }
        }
    }

    pub async fn ttl(&self, k: &str) -> Result<i64> {
        match self {
            CacheService::Memory(m) => m.ttl(k).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.ttl(k).await
            }
        }
    }

    pub async fn get_one_use(&self, k: &str) -> Result<String> {
        match self {
            CacheService::Memory(m) => m.get_one_use(k).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.get_one_use(k).await
            }
        }
    }

    pub async fn get_all(&self) -> Result<Vec<(String, String)>> {
        match self {
            CacheService::Memory(m) => m.get_all().await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.get_all().await
            }
        }
    }

    pub async fn get_all_paginated(
        &self,
        page_num: u64,
        page_size: u64,
        search_key: Option<String>,
    ) -> Result<ListData<CacheItem>> {
        match self {
            CacheService::Memory(m) => m.get_all_paginated(page_num, page_size, search_key).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis
                    .get_all_paginated(page_num, page_size, search_key)
                    .await
            }
        }
    }

    pub async fn get_value<T>(&self, k: &str) -> Result<T>
    where
        T: Serialize + for<'de> Deserialize<'de> + Clone,
    {
        match self {
            CacheService::Memory(m) => m.get_value(k).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.get_value(k).await
            }
        }
    }

    pub async fn set_value<T>(&self, k: &str, value: &T) -> Result<String>
    where
        T: Serialize + Sync,
    {
        match self {
            CacheService::Memory(m) => m.set_value(k, value).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.set_value(k, value).await
            }
        }
    }

    pub async fn set_value_ex<T>(&self, k: &str, value: &T, t: i32) -> Result<bool>
    where
        T: Serialize + Sync,
    {
        match self {
            CacheService::Memory(m) => m.set_value_ex(k, value, t).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.set_value_ex(k, value, t).await
            }
        }
    }

    // 命名空间相关方法
    pub async fn with_namespace(&self, namespace: String) {
        match self {
            CacheService::Memory(m) => m.set_namespace(namespace),
            CacheService::Redis(r) => {
                if let Ok(mut redis) = r.get().await.map_err(|e| e.to_string()) {
                    redis.set_namespace(namespace)
                }
            }
        };
    }
    pub async fn set_namespace(&self, namespace: String) {
        match self {
            CacheService::Memory(m) => m.set_namespace(namespace),
            CacheService::Redis(r) => {
                if let Ok(mut redis) = r.get().await.map_err(|e| e.to_string()) {
                    redis.set_namespace(namespace)
                }
            }
        }
    }
    pub async fn namespaced_key(&self, key: &str) -> String {
        match self {
            CacheService::Memory(m) => m.namespaced_key(key),
            CacheService::Redis(r) => {
                if let Ok(redis) = r.get().await.map_err(|e| e.to_string()) {
                    redis.namespaced_key(key)
                } else {
                    "".to_string()
                }
            }
        }
    }
    pub async fn namespaced_keys(&self, keys: Vec<String>) -> Vec<String> {
        match self {
            CacheService::Memory(m) => m.namespaced_keys(keys),
            CacheService::Redis(r) => {
                if let Ok(redis) = r.get().await.map_err(|e| e.to_string()) {
                    redis.namespaced_keys(keys)
                } else {
                    vec![]
                }
            }
        }
    }

    // Redis数据结构操作方法
    pub async fn brpop(
        &self,
        keys: Vec<String>,
        timeout: usize,
    ) -> Result<Option<(String, String)>> {
        match self {
            CacheService::Memory(m) => m.brpop(keys, timeout).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.abrpop(keys, timeout).await
            }
        }
    }

    pub async fn sadd(&self, key: &str, members: &[&str]) -> Result<i64> {
        match self {
            CacheService::Memory(m) => m.sadd(key, members).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.sadd(key, members).await
            }
        }
    }

    pub async fn set_nx_ex<V>(&self, key: &str, value: V, ttl_in_seconds: usize) -> Result<bool>
    where
        V: ToString + Send + Sync,
    {
        match self {
            CacheService::Memory(m) => m.set_nx_ex(key, value, ttl_in_seconds).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.set_nx_ex(key, value, ttl_in_seconds).await
            }
        }
    }
    pub async fn zrange(&self, key: &str, start: i64, stop: i64) -> Result<Vec<String>> {
        match self {
            CacheService::Memory(m) => m.zrange(key, start, stop).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.azrange(key, start as isize, stop as isize).await
            }
        }
    }

    pub async fn zrangebyscore_limit<S>(
        &self,
        key: &str,
        min_score: f64,
        max_score: f64,
        offset: isize,
        count: isize,
    ) -> Result<Vec<String>>
    where
        S: Into<f64> + Send + Sync,
    {
        match self {
            CacheService::Memory(m) => {
                m.zrangebyscore_limit(key, min_score, max_score, offset, count)
                    .await
            }
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis
                    .azrangebyscore_limit(key, min_score, max_score, offset, count)
                    .await
            }
        }
    }

    pub async fn zadd<V, S>(&self, key: &str, value: V, score: S) -> Result<i64>
    where
        V: ToString + Send + Sync,
        S: Into<f64> + Send + Sync,
    {
        match self {
            CacheService::Memory(m) => m.zadd(key, value, score).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.azadd(key, value, score).await
            }
        }
    }

    pub async fn lpush<V>(&self, key: &str, value: V) -> Result<i64>
    where
        V: ToString + Send + Sync,
    {
        match self {
            CacheService::Memory(m) => m.lpush(key, value).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.lpush(key, value).await
            }
        }
    }

    pub async fn zadd_ch<V, S>(&self, key: &str, value: V, score: S) -> Result<i64>
    where
        V: ToString + Send + Sync,
        S: Into<f64> + Send + Sync,
    {
        match self {
            CacheService::Memory(m) => m.zadd_ch(key, value, score).await,
            CacheService::Redis(r) => {
                let mut redis: bb8::PooledConnection<'_, redis_pool::RedisConnectionManager> = r.get().await.map_err(|e| e.to_string())?;
                redis.azadd_ch(key, value, score).await
            }
        }
    }

    pub async fn zrem<V>(&self, key: &str, value: V) -> Result<bool>
    where
        V: ToString + Send + Sync,
    {
        match self {
            CacheService::Memory(m) => m.zrem(key, value).await,
            CacheService::Redis(r) => {
                let mut redis = r.get().await.map_err(|e| e.to_string())?;
                redis.azrem(key, value).await
            }
        }
    }
}
