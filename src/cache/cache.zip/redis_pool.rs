use crate::common::error::Result as APResult;
use crate::config::APPCOFIG;
use crate::model::prelude::ListData;
use crate::model::sys::args::acache::CacheItem;
use async_trait::async_trait;
use bb8::{CustomizeConnection, ManageConnection, Pool};
use redis::AsyncCommands;
pub use redis::RedisError;
use redis::ToRedisArgs;
pub use redis::Value as RedisValue;
use redis::{aio::Connection, ErrorKind};
use redis::{Client, IntoConnectionInfo};
use std::ops::DerefMut;
use tokio::sync::OnceCell;
pub type RedisPool = Pool<RedisConnectionManager>;
use tracing::{error, info};

static REDISPROCESS: OnceCell<RedisPool> = OnceCell::const_new();

pub async fn connect_redis() -> RedisPool {
    let config = APPCOFIG.clone();
    let redis = &config.cache.redisconfig.unwrap();
    let manager = RedisConnectionManager::new(redis.uri.clone()).unwrap();

    let redis = Pool::builder().build(manager.clone()).await.unwrap();

    if redis.get().await.is_ok() {
        info!("Redis连接成功");
    } else {
        error!("Redis连接失败");
    }
    redis
}

pub async fn redispool() -> &'static RedisPool {
    REDISPROCESS.get_or_init(connect_redis).await
}

#[derive(Debug)]
pub struct NamespaceCustomizer {
    namespace: String,
}

#[async_trait]
impl CustomizeConnection<RedisCacheService, RedisError> for NamespaceCustomizer {
    async fn on_acquire(&self, connection: &mut RedisCacheService) -> Result<(), RedisError> {
        connection.set_namespace(self.namespace.clone());
        Ok(())
    }
}

pub struct RedisCacheService {
    connection: Connection,
    namespace: Option<String>,
}

pub fn with_custom_namespace(namespace: String) -> Box<NamespaceCustomizer> {
    Box::new(NamespaceCustomizer { namespace })
}

#[derive(Clone, Debug)]
pub struct RedisConnectionManager {
    client: Client,
}

impl RedisConnectionManager {
    pub fn new<T: IntoConnectionInfo>(info: T) -> Result<Self, RedisError> {
        Ok(Self {
            client: Client::open(info.into_connection_info()?)?,
        })
    }
}

#[async_trait]
impl ManageConnection for RedisConnectionManager {
    type Connection = RedisCacheService;
    type Error = RedisError;

    async fn connect(&self) -> Result<Self::Connection, Self::Error> {
        Ok(RedisCacheService::new(
            self.client.get_async_connection().await?,
        ))
    }

    async fn is_valid(&self, mut conn: &mut Self::Connection) -> Result<(), Self::Error> {
        let pong: String = redis::cmd("PING")
            .query_async(&mut conn.deref_mut().connection)
            .await?;
        match pong.as_str() {
            "PONG" => Ok(()),
            _ => Err((ErrorKind::ResponseError, "ping request").into()),
        }
    }

    fn has_broken(&self, _conn: &mut Self::Connection) -> bool {
        false
    }
}

impl RedisCacheService {
    // 创建一个新的RedisCacheService实例
    pub fn new(connection: Connection) -> Self {
        Self {
            connection,
            namespace: None,
        }
    }

    // 设置命名空间
    pub fn set_namespace(&mut self, namespace: String) {
        self.namespace = Some(namespace);
    }

    // 返回一个新的RedisCacheService实例，带有命名空间
    #[must_use]
    pub fn with_namespace(self, namespace: String) -> Self {
        Self {
            connection: self.connection,
            namespace: Some(namespace),
        }
    }

    // 返回带有命名空间的键
    pub fn namespaced_key(&self, key: &str) -> String {
        if let Some(ref namespace) = self.namespace {
            return format!("{namespace}:{key}");
        }
        key.to_string()
    }

    // 返回带有命名空间的键列表
    pub fn namespaced_keys(&self, keys: Vec<String>) -> Vec<String> {
        if let Some(ref namespace) = self.namespace {
            let keys: Vec<String> = keys
                .iter()
                .map(|key| format!("{namespace}:{key}"))
                .collect();

            return keys;
        }

        keys
    }
    // 返回可变引用的连接
    pub fn unnamespaced_borrow_mut(&mut self) -> &mut Connection {
        &mut self.connection
    }
    pub async fn abrpop(
        &mut self,
        keys: Vec<String>,
        timeout: usize,
    ) -> APResult<Option<(String, String)>> {
        // 调用brpop方法，获取命名空间后的键
        let result = self
            .connection
            .brpop(self.namespaced_keys(keys), timeout)
            .await;
        match result {
            Ok(Some((key, value))) => Ok(Some((key, value))),
            Ok(None) => Ok(None),
            Err(e) => Err(format!("Failed to pop from Redis: {}", e).into()),
        }
    }

    // 从队列中弹出元素
    pub async fn brpop(
        &mut self,
        keys: Vec<String>,
        timeout: usize,
    ) -> Result<Option<(String, String)>, RedisError> {
        self.connection
            .brpop(self.namespaced_keys(keys), timeout)
            .await
    }

    // 返回带有命名空间的命令
    pub fn cmd_with_key(&mut self, cmd: &str, key: &str) -> redis::Cmd {
        let mut c = redis::cmd(cmd);
        c.arg(self.namespaced_key(key));
        c
    }

    // 删除键
    pub async fn remove(&mut self, key: &str) -> APResult<usize> {
        match self.connection.del(self.namespaced_key(key)).await {
            Ok(count) => Ok(count),
            Err(e) => Err(format!("Failed to delete key '{}': {}", key, e).into()),
        }
    }

    // 设置键的过期时间
    pub async fn expire(&mut self, key: &str, value: usize) -> Result<usize, RedisError> {
        self.connection
            .expire(self.namespaced_key(key), value)
            .await
    }
    pub async fn set_string(&mut self, k: &str, v: &str) -> APResult<String> {
        let namespaced_key = self.namespaced_key(k);
        let _: () = self
            .connection
            .set(&namespaced_key, v)
            .await
            .map_err(|e| e.to_string())?;
        Ok(v.to_string())
    }

    pub async fn set_string_ex(&mut self, k: &str, v: &str, t: i32) -> APResult<bool> {
        let namespaced_key = self.namespaced_key(k);
        let _: () = self
            .connection
            .set_ex(&namespaced_key, v, (t as u64).try_into().unwrap())
            .await
            .map_err(|e| e.to_string())?;
        Ok(true)
    }

    pub async fn get_value<T>(&mut self, k: &str) -> APResult<T>
    where
        T: serde::Serialize + for<'de> serde::Deserialize<'de> + Clone,
    {
        let serialized_value = self.get_string(k).await?;
        let deserialized_value: T = serde_json::from_str(&serialized_value)
            .map_err(|e| format!("Failed to deserialize value: {}", e))?;
        Ok(deserialized_value)
    }

    pub async fn set_value<T>(&mut self, k: &str, value: &T) -> APResult<String>
    where
        T: serde::Serialize + Sync,
    {
        let serialized = serde_json::to_string(value)
            .map_err(|e| format!("Failed to serialize value: {}", e))?;
        self.set_string(k, &serialized).await
    }
    pub async fn set_value_ex<T>(&mut self, k: &str, value: &T, t: i32) -> APResult<bool>
    where
        T: serde::Serialize + Sync,
    {
        let serialized = serde_json::to_string(value)
            .map_err(|e| format!("Failed to serialize value: {}", e))?;
        self.set_string_ex(k, &serialized, t).await
    }

    // 异步函数，获取字符串
    pub async fn get_string(&mut self, k: &str) -> APResult<String> {
        // 获取命名空间键
        let namespaced_key = self.namespaced_key(k);
        // 从连接中获取键对应的值
        let result: Option<String> = self
            .connection
            .get(&namespaced_key)
            .await
            .map_err(|e| e.to_string())?;
        // 匹配结果
        match result {
            // 如果有值，返回值
            Some(value) => Ok(value),
            // 如果没有值，返回错误
            None => Err("Key not found".into()),
        }
    }
    pub async fn contains_key(&mut self, k: &str) -> bool {
        let namespaced_key = self.namespaced_key(k);
        let exists: bool = self
            .connection
            .exists(&namespaced_key)
            .await
            .map_err(|e| e.to_string())
            .unwrap_or_default();
        exists
    }
    pub async fn ttl(&mut self, k: &str) -> APResult<i64> {
        let namespaced_key = self.namespaced_key(k);
        let ttl_seconds: i64 = self
            .connection
            .ttl(&namespaced_key)
            .await
            .map_err(|e| e.to_string())?;
        Ok(ttl_seconds)
    }
    pub async fn get_one_use(&mut self, k: &str) -> APResult<String> {
        let gstr = self.get_string(k).await;
        let _ = self.remove(k).await;
        gstr
    }
    pub async fn get_all(&mut self) -> APResult<Vec<(String, String)>> {
        let pattern = if let Some(ref namespace) = self.namespace {
            format!("{}:*", namespace)
        } else {
            "*".to_string()
        };

        let mut all_keys = Vec::new();
        let mut cursor = 0u64;

        // 使用 SCAN 命令获取所有匹配的键
        loop {
            let (new_cursor, mut keys): (u64, Vec<String>) = redis::cmd("SCAN")
                .arg(cursor)
                .arg("MATCH")
                .arg(&pattern)
                .arg("COUNT")
                .arg(1000)
                .query_async(&mut self.connection)
                .await
                .map_err(|e| e.to_string())?;

            all_keys.append(&mut keys);
            cursor = new_cursor;

            if cursor == 0 {
                break;
            }
        }

        if all_keys.is_empty() {
            return Ok(Vec::new());
        }

        // 批量获取所有键的值
        let values: Vec<Option<String>> = self
            .connection
            .mget(&all_keys)
            .await
            .map_err(|e| e.to_string())?;

        let mut result = Vec::new();
        for (key, value) in all_keys.iter().zip(values.iter()) {
            if let Some(v) = value {
                // 移除命名空间前缀用于显示
                let display_key = if let Some(ref namespace) = self.namespace {
                    let prefix = format!("{}:", namespace);
                    key.strip_prefix(&prefix).unwrap_or(key).to_string()
                } else {
                    key.clone()
                };
                result.push((display_key, v.clone()));
            }
        }

        Ok(result)
    }

    pub async fn get_all_paginated(
        &mut self,
        page_num: u64,
        page_size: u64,
        search_key: Option<String>,
    ) -> APResult<ListData<CacheItem>> {
        // 构建搜索模式
        let pattern = match search_key {
            Some(key) if !key.is_empty() => {
                if let Some(ref namespace) = self.namespace {
                    format!("{}:*{}*", namespace, key)
                } else {
                    format!("*{}*", key)
                }
            }
            _ => {
                if let Some(ref namespace) = self.namespace {
                    format!("{}:*", namespace)
                } else {
                    "*".to_string()
                }
            }
        };

        // 只获取当前页需要的键（避免获取所有键）
        let mut page_keys = Vec::new();
        let mut total_count = 0u64;
        let mut cursor = 0u64;
        let skip_count = (page_num.saturating_sub(1)) * page_size;
        let mut current_count = 0u64;

        loop {
            let (new_cursor, keys): (u64, Vec<String>) = redis::cmd("SCAN")
                .arg(cursor)
                .arg("MATCH")
                .arg(&pattern)
                .arg("COUNT")
                .arg(100)
                .query_async(&mut self.connection)
                .await
                .map_err(|e| e.to_string())?;

            for key in keys {
                if current_count >= skip_count && page_keys.len() < page_size as usize {
                    page_keys.push(key);
                }
                current_count += 1;
                total_count += 1;
            }

            cursor = new_cursor;
            if cursor == 0 || (page_keys.len() >= page_size as usize) {
                break;
            }
        }

        // 如果还没有完整扫描，继续统计总数
        if cursor != 0 {
            loop {
                let (new_cursor, keys): (u64, Vec<String>) = redis::cmd("SCAN")
                    .arg(cursor)
                    .arg("MATCH")
                    .arg(&pattern)
                    .arg("COUNT")
                    .arg(1000)
                    .query_async(&mut self.connection)
                    .await
                    .map_err(|e| e.to_string())?;

                total_count += keys.len() as u64;
                cursor = new_cursor;
                if cursor == 0 {
                    break;
                }
            }
        }

        let total_pages = if page_size > 0 {
            (total_count + page_size - 1) / page_size
        } else {
            1
        };

        // 获取值并构建结果
        let mut cache_items = Vec::new();
        if !page_keys.is_empty() {
            // 移除命名空间前缀并获取值
            let clean_keys: Vec<&str> = page_keys
                .iter()
                .map(|key| {
                    if let Some(ref namespace) = self.namespace {
                        let prefix = format!("{}:", namespace);
                        if key.starts_with(&prefix) {
                            key.strip_prefix(&prefix).unwrap_or(key)
                        } else {
                            key.as_str()
                        }
                    } else {
                        key.as_str()
                    }
                })
                .collect();

            let key_values = self.get_multiple_keys(clean_keys).await?;
            cache_items = key_values
                .into_iter()
                .map(|(key, value)| CacheItem { key, value })
                .collect();
        }

        Ok(ListData {
            list: cache_items,
            total: total_count,
            total_pages,
            page_num,
        })
    }
    pub async fn get_multiple_keys(&mut self, keys: Vec<&str>) -> APResult<Vec<(String, String)>> {
        if keys.is_empty() {
            return Ok(Vec::new());
        }

        // 为每个键添加命名空间前缀
        let namespaced_keys: Vec<String> =
            keys.iter().map(|key| self.namespaced_key(key)).collect();

        // 批量获取所有键的值
        let values: Vec<Option<String>> = self
            .connection
            .mget(&namespaced_keys)
            .await
            .map_err(|e| e.to_string())?;

        let mut result = Vec::new();
        for (key, value) in keys.iter().zip(values.iter()) {
            if let Some(v) = value {
                result.push((key.to_string(), v.clone()));
            }
        }

        Ok(result)
    }

    // 向列表中添加元素
    pub async fn lpush<V>(&mut self, key: &str, value: V) -> APResult<i64>
    where
        V: ToString + Send + Sync,
    {
        let result: i64 = self
            .connection
            .lpush(self.namespaced_key(&key.to_string()), value.to_string())
            .await
            .map_err(|e| e.to_string())?;
        Ok(result)
    }

    pub async fn sadd<V>(&mut self, key: &str, value: V) -> APResult<i64>
    where
        V: ToRedisArgs + Send + Sync,
    {
        let result: i64 = redis::cmd("SADD")
            .arg(self.namespaced_key(key))
            .arg(value)
            .query_async(self.unnamespaced_borrow_mut())
            .await
            .map_err(|e| e.to_string())?;
        Ok(result)
    }

    // 设置键的值，如果键不存在则设置成功
    pub async fn set_nx_ex<V>(
        &mut self,
        key: &str,
        value: V,
        ttl_in_seconds: usize,
    ) -> APResult<bool>
    where
        V: ToString + Send + Sync,
    {
        redis::cmd("SET")
            .arg(self.namespaced_key(key))
            .arg(value.to_string())
            .arg("NX")
            .arg("EX")
            .arg(ttl_in_seconds)
            .query_async(self.unnamespaced_borrow_mut())
            .await
            .map_err(|e| e.to_string().into())
    }
    pub async fn azrange(
        &mut self,
        key: &str,
        lower: isize,
        upper: isize,
    ) -> APResult<Vec<String>> {
        let a = self
            .connection
            .zrange(self.namespaced_key(key), lower, upper)
            .await
            .map_err(|e| e.to_string())?;
        Ok(a)
    }

    // 返回有序集合中指定范围内的元素
    pub async fn zrange(
        &mut self,
        key: &str,
        lower: isize,
        upper: isize,
    ) -> Result<Vec<String>, RedisError> {
        self.connection
            .zrange(self.namespaced_key(key), lower, upper)
            .await
    }

    pub async fn azrangebyscore_limit<S>(
        &mut self,
        key: &str,
        lower: S,
        upper: S,
        offset: isize,
        limit: isize,
    ) -> APResult<Vec<String>>
    where
        S: Into<f64> + Send + Sync,
    {
        let lower_str = lower.into();
        let upper_f64 = upper.into();

        let a = self
            .connection
            .zrangebyscore_limit(
                self.namespaced_key(key),
                lower_str,
                upper_f64,
                offset,
                limit,
            )
            .await
            .map_err(|e| e.to_string())?;
        Ok(a)
    }

    // 返回有序集合中指定范围内的元素，并限制返回的元素数量
    pub async fn zrangebyscore_limit<L: ToRedisArgs + Send + Sync, U: ToRedisArgs + Sync + Send>(
        &mut self,
        key: &str,
        lower: L,
        upper: U,
        offset: isize,
        limit: isize,
    ) -> APResult<Vec<String>> {
        let a = self
            .connection
            .zrangebyscore_limit(self.namespaced_key(key), lower, upper, offset, limit)
            .await;
        Ok(a?)
    }

    pub async fn azadd<V, S>(&mut self, key: &str, value: V, score: S) -> APResult<i64>
    where
        V: ToString + Send + Sync,
        S: Into<f64> + Send + Sync,
    {
        let value_str = value.to_string();
        let score_f64 = score.into();

        let result: i64 = redis::cmd("ZADD")
            .arg(self.namespaced_key(key))
            .arg(score_f64)
            .arg(value_str)
            .query_async(self.unnamespaced_borrow_mut())
            .await
            .map_err(|e| e.to_string())?;
        Ok(result)
    }

    // 向有序集合中添加元素
    pub async fn zadd<V: ToRedisArgs + Send + Sync, S: ToRedisArgs + Send + Sync>(
        &mut self,
        key: &str,
        value: V,
        score: S,
    ) -> Result<usize, RedisError> {
        self.connection
            .zadd(self.namespaced_key(key), value, score)
            .await
    }

    pub async fn azadd_ch<V, S>(&mut self, key: &str, value: V, score: S) -> APResult<i64>
    where
        V: ToString + Send + Sync,
        S: Into<f64> + Send + Sync,
    {
        let value_str = value.to_string();
        let score_f64 = score.into();

        let result: i64 = redis::cmd("ZADD")
            .arg(self.namespaced_key(key))
            .arg("NX")
            .arg(score_f64)
            .arg(value_str)
            .query_async(self.unnamespaced_borrow_mut())
            .await
            .map_err(|e| e.to_string())?;
        Ok(result)
    }

    // 向有序集合中添加元素，并返回是否成功
    pub async fn zadd_ch<V: ToRedisArgs + Send + Sync, S: ToRedisArgs + Send + Sync>(
        &mut self,
        key: &str,
        value: V,
        score: S,
    ) -> Result<bool, RedisError> {
        redis::cmd("ZADD")
            .arg(self.namespaced_key(key))
            .arg("CH")
            .arg(score)
            .arg(value)
            .query_async(self.unnamespaced_borrow_mut())
            .await
    }
    pub async fn azrem<V>(&mut self, key: &str, value: V) -> APResult<bool>
    where
        V: ToString + Send + Sync,
    {
        let result: bool = redis::cmd("ZREM")
            .arg(self.namespaced_key(key))
            .arg(value.to_string())
            .query_async(self.unnamespaced_borrow_mut())
            .await
            .map_err(|e| e.to_string())?;
        Ok(result)
    }

    // 从有序集合中删除元素
    pub async fn zrem<V>(&mut self, key: &str, value: V) -> Result<bool, RedisError>
    where
        V: ToRedisArgs + Send + Sync,
    {
        self.connection.zrem(self.namespaced_key(key), value).await
    }
}
