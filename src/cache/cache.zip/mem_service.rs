use super::cache_trait::CacheService;
use crate::common::error::Result;
use crate::model::prelude::ListData;
use crate::model::sys::args::acache::CacheItem;
use async_trait::async_trait;
use indexmap::IndexMap;
use serde::{Deserialize, Serialize};
use std::collections::hash_map::RandomState;
use std::collections::{BTreeMap, HashMap, HashSet};
use std::ops::Sub;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::Mutex;
use tracing::info;

// 用于存储不同数据类型
#[derive(Clone)]
pub enum CacheValue {
    String(String),
    List(Vec<String>),
    Set(HashSet<String>),
    ZSet(BTreeMap<String, f64>), // 有序集合，使用 BTreeMap 按分数排序
}

impl Default for CacheValue {
    fn default() -> Self {
        CacheValue::String(String::new())
    }
}

#[derive(Default, Clone)]
pub struct ExtendedMemServiceItem {
    pub value: CacheValue,
    pub expire: Option<(Instant, Duration)>,
}

#[derive(Default)]
pub struct MemService {
    pub cache: Mutex<IndexMap<String, ExtendedMemServiceItem, RandomState>>,
    pub namespace: Option<String>,
}

#[derive(Default, Clone)]
pub struct MemServiceItem {
    pub value: String,
    pub expire: Option<(Instant, Duration)>,
}
impl MemService {
    pub fn new() -> Self {
        Self {
            cache: Mutex::new(IndexMap::new()),
            namespace: None,
        }
    }
    // 创建带命名空间的实例
    pub fn with_namespace(&self, namespace: String) {
        self.namespace = Some(namespace);
    }

    // 设置命名空间
    pub fn set_namespace(&self, namespace: String) {
        self.namespace = Some(namespace);
    }

    // 生成带命名空间的键
    pub fn namespaced_key(&self, key: &str) -> String {
        match &self.namespace {
            Some(ns) => format!("{}:{}", ns, key),
            None => key.to_string(),
        }
    }

    // 批量生成带命名空间的键
    pub fn namespaced_keys(&self, keys: Vec<String>) -> Vec<String> {
        keys.iter().map(|key| self.namespaced_key(key)).collect()
    }

    // 回收过期的缓存项
    pub async fn recycling(&self) {
        let mut map_lock_guard = self.cache.lock().await;
        let mut need_removed = vec![];
        for (k, v) in map_lock_guard.iter() {
            if let Some((instant, duration)) = &v.expire {
                if instant.elapsed() >= *duration {
                    need_removed.push(k.to_string());
                }
            }
        }
        for x in need_removed {
            map_lock_guard.swap_remove(&x);
        }
    }
    pub async fn lpush<V>(&self, key: &str, value: V) -> Result<i64>
    where
        V: ToString + Send + Sync,
    {
        let namespaced_key = self.namespaced_key(key);
        let value_str = value.to_string();
        let mut guard = self.cache.lock().await;

        let item = guard
            .entry(namespaced_key)
            .or_insert_with(|| ExtendedMemServiceItem {
                value: CacheValue::List(Vec::new()),
                expire: None,
            });

        match &mut item.value {
            CacheValue::List(ref mut list) => {
                // 在列表头部插入新元素（左侧推入）
                list.insert(0, value_str);
                Ok(list.len() as i64)
            }
            _ => {
                // 如果不是列表类型，创建新列表
                let mut new_list = Vec::new();
                new_list.push(value_str);
                item.value = CacheValue::List(new_list);
                Ok(1)
            }
        }
    }

    // 设置字符串缓存
    pub async fn set_string(&self, k: &str, v: &str) -> Result<String> {
        let namespaced_key = self.namespaced_key(k);
        let mut guard = self.cache.lock().await;
        guard.insert(
            namespaced_key,
            ExtendedMemServiceItem {
                value: CacheValue::String(v.to_string()),
                expire: None,
            },
        );
        Ok(v.to_string())
    }

    // 获取字符串缓存
    pub async fn get_string(&self, k: &str) -> Result<String> {
        let namespaced_key = self.namespaced_key(k);
        let mut guard = self.cache.lock().await;
        let v = guard.get(&namespaced_key).cloned();

        match v {
            Some(item) => {
                if let Some((instant, duration)) = &item.expire {
                    if instant.elapsed() >= *duration {
                        guard.swap_remove(&namespaced_key);
                        return Ok("".to_string());
                    }
                }
                match item.value {
                    CacheValue::String(value) => Ok(value),
                    _ => Err("Type mismatch: expected string".into()),
                }
            }
            None => Err("Key not found".into()),
        }
    }

    // 设置带过期时间的字符串缓存
    pub async fn set_string_ex(&self, k: &str, v: &str, t: i32) -> Result<bool> {
        let namespaced_key = self.namespaced_key(k);
        let mut locked = self.cache.lock().await;
        let e = Some((Instant::now(), Duration::from_secs(t as u64)));
        let _inserted = locked.insert(
            namespaced_key,
            ExtendedMemServiceItem {
                value: CacheValue::String(v.to_string()),
                expire: e,
            },
        );
        Ok(true)
    }

    // 移除指定键的缓存项
    pub async fn remove(&self, k: &str) -> Result<usize> {
        let namespaced_key = self.namespaced_key(k);
        let mut guard = self.cache.lock().await;
        let removed = guard.swap_remove(&namespaced_key);
        Ok(if removed.is_some() { 1 } else { 0 })
    }

    // 检查键是否存在
    pub async fn contains_key(&self, k: &str) -> bool {
        let namespaced_key = self.namespaced_key(k);
        let guard = self.cache.lock().await;
        if let Some(item) = guard.get(&namespaced_key) {
            // 检查是否过期
            if let Some((instant, duration)) = &item.expire {
                if instant.elapsed() >= *duration {
                    return false;
                }
            }
            true
        } else {
            false
        }
    }

    // 获取指定键的剩余时间
    pub async fn ttl(&self, k: &str) -> Result<i64> {
        let namespaced_key = self.namespaced_key(k);
        let locked = self.cache.lock().await;
        let v = locked.get(&namespaced_key).cloned();
        drop(locked);
        match v {
            None => Ok(-2),
            Some(item) => match item.expire {
                None => Ok(-1),
                Some((instant, duration)) => {
                    let use_time = instant.elapsed();
                    if duration > use_time {
                        return Ok(duration.sub(use_time).as_secs() as i64);
                    }
                    Ok(0)
                }
            },
        }
    }

    // 获取并移除一个缓存项
    pub async fn get_one_use(&self, k: &str) -> Result<String> {
        let gstr = self.get_string(k).await;
        let _ = self.remove(k).await;
        gstr
    }

    // 获取所有缓存项
    pub async fn get_all(&self) -> Result<Vec<(String, String)>> {
        let locked = self.cache.lock().await;
        let mut result = vec![];
        for (k, v) in locked.iter() {
            // 去掉命名空间前缀
            let display_key = if let Some(ns) = &self.namespace {
                let prefix = format!("{}:", ns);
                k.strip_prefix(&prefix).unwrap_or(k).to_string()
            } else {
                k.clone()
            };

            // 检查是否过期
            if let Some((instant, duration)) = &v.expire {
                if instant.elapsed() >= *duration {
                    continue;
                }
            }

            match &v.value {
                CacheValue::String(value) => result.push((display_key, value.clone())),
                CacheValue::List(list) => {
                    result.push((display_key, format!("List[{}]", list.len())))
                }
                CacheValue::Set(set) => result.push((display_key, format!("Set[{}]", set.len()))),
                CacheValue::ZSet(zset) => {
                    result.push((display_key, format!("ZSet[{}]", zset.len())))
                }
            }
        }
        Ok(result)
    }

    // 返回所有的值可分页
    pub async fn get_all_paginated(
        &self,
        page_num: u64,
        page_size: u64,
        search_key: Option<String>,
    ) -> Result<ListData<CacheItem>> {
        self.recycling().await;
        let locked = self.cache.lock().await;
        let mut list = Vec::new();
        let start_index = (page_num - 1) * page_size;
        let end_index = start_index + page_size;
        let mut total: u64 = 0;
        let mut current_index: u64 = 0;

        for (k, v) in locked.iter() {
            // 去掉命名空间前缀用于显示和搜索
            let display_key = if let Some(ns) = &self.namespace {
                let prefix = format!("{}:", ns);
                k.strip_prefix(&prefix).unwrap_or(k).to_string()
            } else {
                k.clone()
            };

            if let Some(search) = &search_key {
                if !display_key.contains(search) {
                    continue;
                }
            }

            // 检查是否过期
            if let Some((instant, duration)) = &v.expire {
                if instant.elapsed() >= *duration {
                    continue;
                }
            }

            if current_index >= start_index && current_index < end_index {
                let value_str = match &v.value {
                    CacheValue::String(value) => value.clone(),
                    CacheValue::List(list) => format!("List[{}]", list.len()),
                    CacheValue::Set(set) => format!("Set[{}]", set.len()),
                    CacheValue::ZSet(zset) => format!("ZSet[{}]", zset.len()),
                };

                list.push(CacheItem {
                    key: display_key,
                    value: value_str,
                });
            }
            current_index += 1;
            total += 1;
        }

        let total_pages = if total % page_size == 0 {
            total / page_size
        } else {
            total / page_size + 1
        };

        let list_data = ListData {
            list,
            page_num,
            total,
            total_pages,
        };
        Ok(list_data)
    }

    // 获取序列化的值
    pub async fn get_value<T>(&self, k: &str) -> Result<T>
    where
        T: Serialize + for<'de> Deserialize<'de> + Clone,
    {
        let serialized_value = self.get_string(k).await?;
        let deserialized_value: T = serde_json::from_str(&serialized_value)?;
        Ok(deserialized_value)
    }

    // 设置序列化的值
    pub async fn set_value<T>(&self, k: &str, value: &T) -> Result<String>
    where
        T: Serialize + Sync,
    {
        let serialized = serde_json::to_string(value)?;
        self.set_string(k, &serialized).await
    }

    // 设置带过期时间的序列化值
    pub async fn set_value_ex<T>(&self, k: &str, value: &T, t: i32) -> Result<bool>
    where
        T: Serialize + Sync,
    {
        let serialized = serde_json::to_string(value)?;
        self.set_string_ex(k, &serialized, t).await
    }

    // Redis数据结构操作方法
    pub async fn brpop(
        &self,
        keys: Vec<String>,
        timeout: usize,
    ) -> Result<Option<(String, String)>> {
        let namespaced_keys = self.namespaced_keys(keys.clone());
        let start_time = Instant::now();
        let timeout_duration = Duration::from_secs(timeout as u64);

        loop {
            let mut guard = self.cache.lock().await;

            for (original_key, namespaced_key) in keys.iter().zip(namespaced_keys.iter()) {
                if let Some(item) = guard.get_mut(namespaced_key) {
                    if let Some((instant, duration)) = &item.expire {
                        if instant.elapsed() >= *duration {
                            guard.swap_remove(namespaced_key);
                            continue;
                        }
                    }

                    if let CacheValue::List(ref mut list) = item.value {
                        if let Some(value) = list.pop() {
                            if list.is_empty() {
                                guard.swap_remove(namespaced_key);
                            }
                            return Ok(Some((original_key.to_string(), value)));
                        }
                    }
                }
            }

            drop(guard);

            if start_time.elapsed() >= timeout_duration {
                break;
            }

            tokio::time::sleep(Duration::from_millis(100)).await;
        }

        Ok(None)
    }
    pub async fn set_nx_ex<V>(&mut self, key: &str, value: V, ttl_in_seconds: usize) -> Result<bool>
    where
        V: ToString + Send + Sync,
    {
        let namespaced_key = self.namespaced_key(key);
        let mut guard = self.cache.lock().await;

        // 检查键是否已存在且未过期
        if let Some(existing_item) = guard.get(&namespaced_key) {
            // 检查是否过期
            if let Some((instant, duration)) = &existing_item.expire {
                if instant.elapsed() < *duration {
                    // 键存在且未过期，返回 false（未设置）
                    return Ok(false);
                }
            } else {
                // 键存在且无过期时间，返回 false（未设置）
                return Ok(false);
            }
        }

        // 键不存在或已过期，设置新值
        let expire_time = Some((Instant::now(), Duration::from_secs(ttl_in_seconds as u64)));
        guard.insert(
            namespaced_key,
            ExtendedMemServiceItem {
                value: CacheValue::String(value.to_string()),
                expire: expire_time,
            },
        );

        Ok(true) // 成功设置
    }

    pub async fn sadd(&self, key: &str, members: &[&str]) -> Result<i64> {
        let namespaced_key = self.namespaced_key(key);
        let mut guard = self.cache.lock().await;

        let item = guard
            .entry(namespaced_key)
            .or_insert_with(|| ExtendedMemServiceItem {
                value: CacheValue::Set(HashSet::new()),
                expire: None,
            });

        match &mut item.value {
            CacheValue::Set(ref mut set) => {
                let mut added_count = 0;
                for &member in members {
                    if set.insert(member.to_string()) {
                        added_count += 1;
                    }
                }
                Ok(added_count)
            }
            _ => {
                let mut new_set = HashSet::new();
                let mut added_count = 0;
                for &member in members {
                    if new_set.insert(member.to_string()) {
                        added_count += 1;
                    }
                }
                item.value = CacheValue::Set(new_set);
                Ok(added_count)
            }
        }
    }

    pub async fn zrange(&self, key: &str, start: i64, stop: i64) -> Result<Vec<String>> {
        let namespaced_key = self.namespaced_key(key);
        let guard = self.cache.lock().await;

        if let Some(item) = guard.get(&namespaced_key) {
            if let Some((instant, duration)) = &item.expire {
                if instant.elapsed() >= *duration {
                    return Ok(vec![]);
                }
            }

            if let CacheValue::ZSet(ref zset) = item.value {
                let mut sorted_members: Vec<_> = zset.iter().collect();
                sorted_members.sort_by(|a, b| a.1.partial_cmp(b.1).unwrap());

                let len = sorted_members.len() as i64;
                let start_idx = if start < 0 {
                    (len + start).max(0)
                } else {
                    start.min(len)
                } as usize;
                let stop_idx = if stop < 0 {
                    (len + stop + 1).max(0)
                } else {
                    (stop + 1).min(len)
                } as usize;

                if start_idx >= stop_idx {
                    return Ok(vec![]);
                }

                let result = sorted_members[start_idx..stop_idx]
                    .iter()
                    .map(|(member, _)| (*member).clone())
                    .collect();

                Ok(result)
            } else {
                Ok(vec![])
            }
        } else {
            Ok(vec![])
        }
    }

    pub async fn zrangebyscore_limit<S>(
        &self,
        key: &str,
        min_score: S,
        max_score: S,
        offset: isize,
        count: isize,
    ) -> Result<Vec<String>>
    where
        S: Into<f64> + Send + Sync,
    {
        let namespaced_key = self.namespaced_key(key);
        let guard = self.cache.lock().await;

        if let Some(item) = guard.get(&namespaced_key) {
            if let Some((instant, duration)) = &item.expire {
                if instant.elapsed() >= *duration {
                    return Ok(vec![]);
                }
            }

            if let CacheValue::ZSet(ref zset) = item.value {
                let min_f64 = min_score.into();
                let max_f64 = max_score.into();

                let mut filtered_members: Vec<_> = zset
                    .iter()
                    .filter(|(_, &score)| score >= min_f64 && score <= max_f64)
                    .collect();

                filtered_members.sort_by(|a, b| a.1.partial_cmp(b.1).unwrap());

                let result = filtered_members
                    .into_iter()
                    .skip(offset as usize)
                    .take(count as usize)
                    .map(|(member, _)| member.clone())
                    .collect();

                Ok(result)
            } else {
                Ok(vec![])
            }
        } else {
            Ok(vec![])
        }
    }

    pub async fn zadd<V, S>(&self, key: &str, value: V, score: S) -> Result<i64>
    where
        V: ToString + Send + Sync,
        S: Into<f64> + Send + Sync,
    {
        let namespaced_key = self.namespaced_key(key);
        let mut guard = self.cache.lock().await;

        let item = guard
            .entry(namespaced_key)
            .or_insert_with(|| ExtendedMemServiceItem {
                value: CacheValue::ZSet(BTreeMap::new()),
                expire: None,
            });

        match &mut item.value {
            CacheValue::ZSet(ref mut zset) => {
                let member_str = value.to_string();
                let score_f64 = score.into();

                // 检查成员是否已存在
                let is_new = !zset.contains_key(&member_str);
                zset.insert(member_str, score_f64);

                // 返回新增的元素数量（0或1）
                Ok(if is_new { 1 } else { 0 })
            }
            _ => {
                // 如果不是ZSet类型，创建新的ZSet
                let mut new_zset = BTreeMap::new();
                let member_str = value.to_string();
                let score_f64 = score.into();
                new_zset.insert(member_str, score_f64);

                item.value = CacheValue::ZSet(new_zset);
                Ok(1) // 新增了1个元素
            }
        }
    }

    pub async fn zadd_ch<V, S>(&self, key: &str, value: V, score: S) -> Result<i64>
    where
        V: ToString + Send + Sync,
        S: Into<f64> + Send + Sync,
    {
        let namespaced_key = self.namespaced_key(key);
        let mut guard = self.cache.lock().await;

        let item = guard
            .entry(namespaced_key)
            .or_insert_with(|| ExtendedMemServiceItem {
                value: CacheValue::ZSet(BTreeMap::new()),
                expire: None,
            });

        match &mut item.value {
            CacheValue::ZSet(ref mut zset) => {
                let member_string = value.to_string();
                let score_f64 = score.into();

                if let Some(existing_score) = zset.get(&member_string) {
                    if *existing_score != score_f64 {
                        zset.insert(member_string, score_f64);
                        Ok(1) // 分数发生了变化
                    } else {
                        Ok(0) // 分数没有变化
                    }
                } else {
                    zset.insert(member_string, score_f64);
                    Ok(1) // 新增了元素
                }
            }
            _ => {
                // 如果不是ZSet类型，创建新的ZSet
                let mut new_zset = BTreeMap::new();
                let member_string = value.to_string();
                let score_f64 = score.into();
                new_zset.insert(member_string, score_f64);

                item.value = CacheValue::ZSet(new_zset);
                Ok(1) // 新增了1个元素
            }
        }
    }

    pub async fn zrem<V>(&self, key: &str, value: V) -> Result<bool>
    where
        V: ToString + Send + Sync,
    {
        let namespaced_key = self.namespaced_key(key);
        let mut guard = self.cache.lock().await;

        if let Some(item) = guard.get_mut(&namespaced_key) {
            if let Some((instant, duration)) = &item.expire {
                if instant.elapsed() >= *duration {
                    guard.swap_remove(&namespaced_key);
                    return Ok(false);
                }
            }

            match &mut item.value {
                CacheValue::ZSet(ref mut zset) => {
                    let member_string = value.to_string();
                    let removed = if zset.remove(&member_string).is_some() {
                        true
                    } else {
                        false
                    };

                    if zset.is_empty() {
                        guard.swap_remove(&namespaced_key);
                    }

                    Ok(removed)
                }
                _ => Ok(false),
            }
        } else {
            Ok(false)
        }
    }
}
