pub mod cache_trait;
pub mod mem_service;
pub mod redis_pool;
use crate::common::error::Result;
use crate::config::APPCOFIG;
use crate::model::prelude::ListData;
use crate::model::sys::args::acache::CacheItem;
use cache_trait::CacheService;
use dashmap::DashMap;
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::sync::{Mutex, OnceCell, RwLock};

// 全局缓存实例
static GLOBAL_CACHE: OnceCell<GlobalCache> = OnceCell::const_new();

#[derive(Clone)]
pub struct GlobalCache {
    cache_service: Arc<CacheService>, // 直接存储缓存服务实例
}

impl GlobalCache {
    fn new(cache_service: CacheService) -> Self {
        GlobalCache {
            cache_service: Arc::new(cache_service),
        }
    }

    // 基础字符串操作 - 无锁访问
    pub async fn contains_key(&self, key: &str) -> bool {
        self.cache_service.contains_key(key).await
    }

    pub async fn get_string(&self, key: &str) -> Result<String> {
        self.cache_service.get_string(key).await
    }

    pub async fn set_string(&self, key: &str, value: &str) -> Result<String> {
        self.cache_service.set_string(key, value).await
    }

    pub async fn set_string_ex(&self, key: &str, value: &str, ttl: i32) -> Result<bool> {
        self.cache_service.set_string_ex(key, value, ttl).await
    }

    pub async fn remove(&self, key: &str) -> Result<usize> {
        self.cache_service.remove(key).await
    }

    pub async fn ttl(&self, key: &str) -> Result<i64> {
        self.cache_service.ttl(key).await
    }

    pub async fn get_one_use(&self, key: &str) -> Result<String> {
        self.cache_service.get_one_use(key).await
    }

    // 泛型值操作
    pub async fn get_value<T>(&self, key: &str) -> Result<T>
    where
        T: Serialize + for<'de> Deserialize<'de> + Clone,
    {
        self.cache_service.get_value(key).await
    }

    pub async fn set_value<T>(&self, key: &str, value: &T) -> Result<String>
    where
        T: Serialize + Sync,
    {
        self.cache_service.set_value(key, value).await
    }

    pub async fn set_value_ex<T>(&self, key: &str, value: &T, ttl: i32) -> Result<bool>
    where
        T: Serialize + Sync,
    {
        self.cache_service.set_value_ex(key, value, ttl).await
    }

    // 批量操作
    pub async fn get_all(&self) -> Result<Vec<(String, String)>> {
        self.cache_service.get_all().await
    }

    pub async fn get_all_paginated(
        &self,
        page_num: u64,
        page_size: u64,
        search_key: Option<String>,
    ) -> Result<ListData<CacheItem>> {
        self.cache_service
            .get_all_paginated(page_num, page_size, search_key)
            .await
    }

    // Redis 数据结构操作
    pub async fn brpop(
        &self,
        keys: Vec<String>,
        timeout: usize,
    ) -> Result<Option<(String, String)>> {
        self.cache_service.brpop(keys, timeout).await
    }

    pub async fn sadd(&self, key: &str, members: &[&str]) -> Result<i64> {
        self.cache_service.sadd(key, members).await
    }

    pub async fn zrange(&self, key: &str, start: i64, stop: i64) -> Result<Vec<String>> {
        self.cache_service.zrange(key, start, stop).await
    }

    pub async fn zrangebyscore_limit(
        &self,
        key: &str,
        min_score: f64,
        max_score: f64,
        offset: isize,
        count: isize,
    ) -> Result<Vec<String>> {
        self.cache_service
            .zrangebyscore_limit::<f64>(key, min_score, max_score, offset, count)
            .await
    }

    pub async fn lpush<V>(&self, key: &str, value: V) -> Result<i64>
    where
        V: ToString + Send + Sync,
    {
        self.cache_service.lpush(key, value).await
    }

    pub async fn zadd<V, S>(&self, key: &str, value: V, score: S) -> Result<i64>
    where
        V: ToString + Send + Sync,
        S: Into<f64> + Send + Sync,
    {
        self.cache_service.zadd(key, value, score).await
    }

    pub async fn zadd_ch<V, S>(&self, key: &str, value: V, score: S) -> Result<i64>
    where
        V: ToString + Send + Sync,
        S: Into<f64> + Send + Sync,
    {
        self.cache_service.zadd_ch(key, value, score).await
    }

    pub async fn zrem<V>(&self, key: &str, value: V) -> Result<bool>
    where
        V: ToString + Send + Sync,
    {
        self.cache_service.zrem(key, value).await
    }

    pub async fn set_nx_ex<V>(&self, key: &str, value: V, ttl_in_seconds: usize) -> Result<bool>
    where
        V: ToString + Send + Sync,
    {
        self.cache_service
            .set_nx_ex(key, value, ttl_in_seconds)
            .await
    }

    // 命名空间操作
    pub async fn set_namespace(&self, namespace: String) {
        self.cache_service.set_namespace(namespace).await;
    }

    pub async fn namespaced_key(&self, key: &str) -> String {
        self.cache_service.namespaced_key(key).await
    }

    pub async fn namespaced_keys(&self, keys: Vec<String>) -> Vec<String> {
        self.cache_service.namespaced_keys(keys).await
    }

    // 回收操作
    pub async fn recycling(&self) {
        self.cache_service.recycling().await;
    }
}

// 初始化管理器
pub struct CacheManager;
// 修改 CacheManager 的实现
impl CacheManager {
    pub async fn init_with_config() -> Result<GlobalCache> {
        let config = APPCOFIG.clone();

        let cache_service = if config.cache.cache_type == "redis" {
            tracing::info!("正在初始化 Redis 缓存服务...");
            match CacheService::new_redis().await {
                Ok(redis_cache) => {
                    tracing::info!("Redis 缓存服务初始化成功");
                    redis_cache
                }
                Err(e) => {
                    tracing::error!("初始化 Redis 缓存服务失败: {}, 回退到内存缓存", e);
                    CacheService::new_memory()
                }
            }
        } else {
            tracing::info!("使用内存缓存服务");
            CacheService::new_memory()
        };

        let global_cache = GlobalCache::new(cache_service);

        // 设置命名空间
        if let Some(namespace) = &config.cache.namespace {
            global_cache.set_namespace(namespace.clone()).await;
            tracing::info!("缓存命名空间设置为: {}", namespace);
        }

        Ok(global_cache)
    }

    // 保持原有的方法以便向后兼容
    pub async fn init_memory() -> Result<()> {
        let cache = GlobalCache::new(CacheService::new_memory());
        GLOBAL_CACHE
            .set(cache)
            .map_err(|_| "Global cache already initialized".to_string())?;
        Ok(())
    }

    pub async fn init_redis() -> Result<()> {
        let cache_service = CacheService::new_redis().await?;
        let cache = GlobalCache::new(cache_service);
        GLOBAL_CACHE
            .set(cache)
            .map_err(|_| "Global cache already initialized".to_string())?;
        Ok(())
    }
}

// 简化的 CACHE 函数
pub async fn CACHE() -> &'static GlobalCache {
    GLOBAL_CACHE
        .get_or_init(|| async {
            match CacheManager::init_with_config().await {
                Ok(cache) => cache,
                Err(e) => {
                    tracing::error!("缓存初始化失败: {}, 使用默认内存缓存", e);
                    GlobalCache::new(CacheService::new_memory())
                }
            }
        })
        .await
}

// 显式初始化函数（推荐在应用启动时调用）
pub async fn init_global_cache() -> Result<()> {
    let cache = CacheManager::init_with_config().await?;
    GLOBAL_CACHE
        .set(cache)
        .map_err(|_| "Global cache already initialized".to_string())?;
    Ok(())
}
